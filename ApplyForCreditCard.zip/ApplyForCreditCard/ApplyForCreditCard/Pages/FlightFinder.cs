﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace BookAFlight.Pages.IndividualClient
{
    public class FlightFinder : BookAFlight.Abstract.BasePage
    {
        public FlightFinder(IWebDriver driver)
            : base(driver)
        {

        }

        public IWebElement Flights => Driver.FindElement(By.XPath("/html/body/div/table/tbody/tr/td[1]/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[2]/td[2]/a"));
        public IWebElement RadioButtonType => Driver.FindElement(By.XPath("/html/body/div/table/tbody/tr/td[1]/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[2]/td[2]/a"));
        public IWebElement RadioButtonServiceClass => Driver.FindElement(By.XPath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[9]/td[2]/font/input"));
        public IWebElement ContinueButton => Driver.FindElement(By.XPath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[14]/td/input"));
        

        public void flightFinder()
        {
            throw new NotImplementedException();
        }

      
        public void flightFinder(string passangers)
        {
            SelectElement PassengersDropDown = new SelectElement(Driver.FindElement(By.Name("passCount")));
            PassengersDropDown.SelectByValue(passangers);
            SelectElement DepartingFromDropDown = new SelectElement(Driver.FindElement(By.Name("fromPort")));
            DepartingFromDropDown.SelectByValue("London");
            SelectElement FromMonthDropDown = new SelectElement(Driver.FindElement(By.Name("fromMonth")));
            FromMonthDropDown.SelectByValue("May");
            SelectElement FromDayDropDown = new SelectElement(Driver.FindElement(By.Name("fromDay")));
            FromDayDropDown.SelectByValue("15");
            SelectElement ArrivingInDropDown = new SelectElement(Driver.FindElement(By.Name("toPort")));
            ArrivingInDropDown.SelectByValue("New York");
            SelectElement ReturnMonthDropDown = new SelectElement(Driver.FindElement(By.Name("toMonth")));
            ReturnMonthDropDown.SelectByValue("June");
            SelectElement ReturnDateDropDown = new SelectElement(Driver.FindElement(By.Name("toDay")));
            ReturnDateDropDown.SelectByValue("1");
            SelectElement AirlineDropDown = new SelectElement(Driver.FindElement(By.Name("airline")));
            AirlineDropDown.SelectByValue("Blue Skies Airlines");
        }
    }
}


