﻿using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;

namespace BookAFlight.Abstract
{
    public abstract class BasePage
    {
        private IWebDriver driver;
        private WebDriverWait wait;

        public BasePage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(this.driver, TimeSpan.FromSeconds(60));
        }

        public IWebDriver Driver => driver;

        public WebDriverWait Wait => wait;

        public virtual void Navigate()
        {
            Driver.Url = GlobalVariables.GlobalConstants.Url;
        }

        public void AcceptAlert()
        {
            Wait.Until(ExpectedConditions.AlertIsPresent());
            IAlert alert = Driver.SwitchTo().Alert();
            alert.Accept();
        }

        public void AlertPresent()
        {
            bool presentFlag = false;
            string alertMessage = string.Empty;
            //while ((presentFlag == false))
            //{
            try
            {
                //Check the presence of alert
                IAlert alert = Driver.SwitchTo().Alert();
                //Alert present; set the flag
                presentFlag = true;
                alertMessage = alert.Text;
                //if present consume the alert
                alert.Accept();
            }
            catch
            {
                //Alert not present
                System.Threading.Thread.Sleep(500);
            }
            //}
        }
        public void NextTab()
        {
            while (this.Driver.WindowHandles.Count == 1)
            {
                Thread.Sleep(50);
            }

            ReadOnlyCollection<String> windowHandles = this.Driver.WindowHandles;
            String nextTab = windowHandles[windowHandles.Count - 1];

            Driver.SwitchTo().Window(nextTab);
        }
        public void PreviousTab()
        {
            ReadOnlyCollection<String> windowHandles = Driver.WindowHandles;
            String previousTab = (String)windowHandles[windowHandles.Count - 2];

            Driver.Close();
            Driver.SwitchTo().Window(previousTab);
        }
        public void SwitchToIframe(IWebElement element)
        {
            Driver.SwitchTo().Frame(element);
        }
        public void SwitchToParent()
        {
            Driver.SwitchTo().ParentFrame();
        }

        public void Screenshot()
        {
            if (TestContext.CurrentContext.Result.Outcome != ResultState.Success)
            {
                var screenshot = ((ITakesScreenshot)Driver).GetScreenshot();
                string timestamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss").ToString();
                screenshot.SaveAsFile($@"C:\Users\rbbkso\Desktop\VisualStudio\Screenshots-{timestamp}.jpg", ScreenshotImageFormat.Png);

            }
        }

        public void WaitingForListToLoad(IList<IWebElement> element)
        {
            while (element.Count <= 0)
            {
                Thread.Sleep(50);
            }
        }

        public void WaitingForElementToLoad(IWebElement element)
        {
            while (!element.Displayed)
            {
                Thread.Sleep(50);
            }
        }


        public void WaitingForSelectElementToLoad(SelectElement element)
        {
            CancellationTokenSource source = new CancellationTokenSource(1000);

            while (true)
            {
                if (element.Options.Count <= 0)
                {
                    source.CancelAfter(1000);

                    if (source.IsCancellationRequested)
                    {
                        break;
                    }
                }
                else if (element.Options.Count > 0)
                {
                    break;
                }
            }
        }
    }
}
