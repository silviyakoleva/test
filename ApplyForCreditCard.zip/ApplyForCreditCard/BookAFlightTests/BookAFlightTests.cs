﻿using System;
using System.IO;
using System.Reflection;
using BookAFlight.Pages.IndividualClient;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace BookAFlightTests.Tests
{
    [TestFixture]
    public class FlightFinderTest
    {
        private FlightFinder flightFinder;
        private IWebDriver driver;
        [SetUp]

        public void Init()
        {
            IWebDriver driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);

            flightFinder = new FlightFinder(driver);
            flightFinder.Navigate();
        }
        [TearDown]
        public void Screenshot()
        {
            flightFinder.Screenshot();

        }

        [Test]
        public void isDisplayContinueButton()
        {
            flightFinder.Flights.Click();
            flightFinder.RadioButtonType.Click();
            flightFinder.RadioButtonServiceClass.Click();
            Assert.IsFalse(flightFinder.ContinueButton.Displayed);
            flightFinder.flightFinder("2");
            
            
        }

    }

}

