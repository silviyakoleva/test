﻿using System;

namespace GlobalVariables
{
    public class GlobalConstants
    {
        public const string Url = "http://newtours.demoaut.com/";
    }
}
