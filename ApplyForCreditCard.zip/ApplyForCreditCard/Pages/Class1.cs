﻿using System;

namespace Pages
{
    public class Class1
    {
    }
}
